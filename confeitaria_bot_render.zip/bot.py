import logging
import os
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

TOKEN = os.getenv("TOKEN")
if not TOKEN:
    raise ValueError("O TOKEN do bot não foi encontrado nas variáveis de ambiente.")

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

menu_principal = [['Fazer Pedido'], ['Ver Cardápio'], ['Falar com Atendente']]
markup_menu = ReplyKeyboardMarkup(menu_principal, resize_keyboard=True)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Bem-vindo à Confeitaria! Escolha uma opção:", reply_markup=markup_menu)

async def responder_mensagem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    texto = update.message.text
    if texto == 'Fazer Pedido':
        await update.message.reply_text("Para fazer um pedido, envie os detalhes:")
    elif texto == 'Ver Cardápio':
        await update.message.reply_text("Nosso cardápio:
- Bolo de pote
- Brownie
- Cupcake")
    elif texto == 'Falar com Atendente':
        await update.message.reply_text("Um atendente falará com você em breve.")
    else:
        await update.message.reply_text("Desculpe, não entendi. Escolha uma opção no menu.")

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, responder_mensagem))
    app.run_polling()